package pkg;

public class ThreadOrdenaçao implements Runnable{

	@Override
	public void run() {
		// TODO Auto-generated method stub
		do
        }
	}

	
}
