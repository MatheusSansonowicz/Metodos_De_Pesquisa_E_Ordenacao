package pkg;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.Random;

/*A partir dos códigos Java gerados na pasta __aulaPratica, com a classe Aluno, adaptar o código,
gerar 60 mil alunos (nomes aleatóreos e idades aleatóreas entre 18 e 70),
 aplicar os métodos sort, bolha, seleção e inserção nas listas geradas.
  Além disso, garantir que a ordenação seja por chave nome e pela segunda chave idade.
Desejável: código documentado oficialmente, uso de threads e trabalho apresentado em mais de uma linguagem.*/

public class PrincipalGeraAluno {
	/**
	 * Classe Principal para testar a atividade
	 * @param args
	 */
	
	static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ArrayList<Aluno> lista = new ArrayList<>();
		ArrayList<Aluno> listaBolha = new ArrayList<>();
		ArrayList<Aluno> listaSelecao = new ArrayList<>();
		ArrayList<Aluno> listaInsercao = new ArrayList<>();
        Random gerador = new Random();
        /*Alunos criados apenas para testar os ordenadores
         * lista.add(new Aluno("Carlos", 20));
        lista.add(new Aluno("Ana", 22));
        lista.add(new Aluno("Carlos", 18));
        lista.add(new Aluno("Bruno", 25));*/
        
        for(int i=0; i<60000;i++) {
        	Aluno a = new Aluno(Util.gerarPalavra(10), gerador.nextInt(18,70));
        	lista.add(a);
        }
        
        MetodosOrdenação.bolha(lista, listaBolha);
        MetodosOrdenação.selecao(lista, listaSelecao);
        MetodosOrdenação.insercao(lista, listaInsercao);
        lista.sort(new Comparator<Aluno>() {
            @Override
            public int compare(Aluno a1, Aluno a2) {
                int nomeCompare = a1.getNome().compareTo(a2.getNome());
                if (nomeCompare != 0) {
                    return nomeCompare;
                } else {
                    return Integer.compare(a1.getIdade(), a2.getIdade());
                }
            }
        });
        
        /*Exibições apenas usadas para testar a ordenação dos metodos
         * System.out.println("Exibindo o sort:");
        Util.exibir(lista, null);
        System.out.println("Exibindo a bolha:");
        Util.exibir(listaBolha, null);
        System.out.println("Exibindo a selecao:");
        Util.exibir(listaSelecao, null);
        System.out.println("Exibindo a insercao:");
        Util.exibir(listaInsercao, null);*/
        
	}

}
